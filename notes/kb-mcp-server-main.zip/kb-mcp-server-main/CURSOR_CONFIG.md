# Cursor MCP Configuration Guide

Quick setup guide for integrating the KB MCP server with Cursor.

## Step 1: GitLab Authentication

### Quick Install (One-Liner)

**Linux/Mac:**
```bash
curl -so- https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.sh | bash
```

Or with wget:
```bash
wget -qO- https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.sh | bash
```

**Windows (PowerShell):**
```powershell
irm https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.ps1 | iex
```

### Manual Setup

Manually edit `~/.npmrc` (or `C:\Users\YourUsername\.npmrc` on Windows):
```
@devops:registry=https://code.gensuite.com/api/v4/packages/npm/
//code.gensuite.com/api/v4/packages/npm/:_authToken=YOUR_PERSONAL_ACCESS_TOKEN
```

**Getting a GitLab token:**
1. Go to https://code.gensuite.com
2. Navigate to User Settings → Access Tokens
3. Create token with `read_api` and `read_registry` scopes
4. Copy immediately (you won't see it again!)

## Step 2: Configure Cursor

1. Open Cursor Settings (Ctrl+, or Cmd+,)
2. Search for "MCP" or navigate to Extensions → MCP
3. Click "Edit Config" or manually edit your Cursor settings JSON
4. Add the following:

```json
{
  "mcpServers": {
    "kb": {
      "command": "npx",
      "args": ["-y", "@devops/kb-mcp-server"]
    }
  }
}
```

**Notes:**
- The `-y` flag auto-accepts package installation
- `KB_ENDPOINT` defaults to `https://tools.benchmarkdigital.com/kb/callKBX.cfm` (only set if different)
- Authentication is handled automatically - no `KB_AUTH_TOKEN` needed unless automatic sign-in fails

## Step 3: Verify

1. Restart Cursor
2. Open a chat conversation
3. Test: "Search the KB for content about ColdFusion"

KB tools should now be available when you mention KB-related tasks.

## Troubleshooting

**Server not starting:**
- Verify Node.js/npm installed and in PATH
- Check `.npmrc` GitLab authentication
- Ensure package is accessible from GitLab Package Registry

**Connection errors:**
- Test endpoint: `https://tools.benchmarkdigital.com/kb/callKBX.cfm?method=getType`
- Check network/firewall settings

**Authentication issues:**
- Verify token has `read_api` and `read_registry` scopes
