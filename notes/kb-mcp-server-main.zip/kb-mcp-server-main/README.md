# Knowledge Base (KB) MCP Server

MCP server for integrating the Knowledge Base system with Cursor and other MCP-compatible clients.

## Overview

The KB MCP server bridges MCP clients and the ColdFusion-based Knowledge Base system, communicating with `callKBX.cfm` which forwards requests to methods in `kbx.cfc`.

## Quick Start

### One-Liner Install (Recommended)

**Linux/Mac:**
```bash
curl -so- https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.sh | bash
```

Or with wget:
```bash
wget -qO- https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.sh | bash
```

**Windows (PowerShell):**
```powershell
irm https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.ps1 | iex
```

This will configure your `.npmrc` file and show you the Cursor configuration.

### Configure Cursor

After running the install script, add the following to your Cursor MCP settings:

```json
{
  "mcpServers": {
    "kb": {
      "command": "npx",
      "args": ["-y", "@devops/kb-mcp-server"],
      "env": {
        "KB_AUTH_TOKEN": "your-jwt-token-if-needed"
      }
    }
  }
}
```

Then **restart Cursor** and start using KB tools in conversations.

See [CURSOR_CONFIG.md](./CURSOR_CONFIG.md) for detailed setup instructions.

## Configuration

Environment variables (configure in Cursor settings, not shell):

- **`KB_ENDPOINT`** (optional): URL to `callKBX.cfm` endpoint
  - Default: `https://tools.benchmarkdigital.com/kb/callKBX.cfm`
  
- **`KB_AUTH_TOKEN`** (optional): JWT token for `Authorization: Bearer` header

## Available Tools

### Content Operations
- **get_content**: Get content by ID
- **search_content**: Search using Elasticsearch (supports `start`/`limit` pagination)
- **save_content**: Save/update content (HTML only, auto base64-encoded)
- **get_recent_content**: Get recently created/updated content
- **find_content_by_title**: Find by exact title match
- **get_content_url**: Get browser URL for KB article

### Favorites
- **get_favorite_content**: Get user's favorites
- **add_favorite**: Add to favorites
- **remove_favorite**: Remove from favorites

### Metadata
- **get_tags**: Get available tags (optionally filtered by type)
- **get_types**: Get content types
- **get_history**: Get audit trail for content

### Advanced
- **call_method**: Call any KB method dynamically

## Usage Examples

- "Search for content about ColdFusion"
- "Get the content with ID 123"
- "Show me recent KB updates"
- "Add content ID 456 to my favorites"

## Content Format

**Important**: `kb_save_content` requires **HTML** content (Markdown not supported). Content is automatically base64-encoded by the server.

Example:
```html
<h1>Article Title</h1>
<p>This is a paragraph with <strong>bold text</strong>.</p>
```

## Development

For contributors:

```bash
git clone https://code.gensuite.com/devops/kb-mcp-server.git
cd kb-mcp-server
npm install
npm run build
```

**Scripts:**
- `npm run dev` - Run stdio server in development mode
- `npm run dev:http` - Run HTTP server in development mode
- `npm run dev:gateway` - Run gateway server in development mode
- `npm run build` - Build TypeScript
- `npm run watch` - Watch for changes
- `npm run start` - Run stdio server (production)
- `npm run start:http` - Run HTTP REST API (production)
- `npm run start:gateway` - Run SSE gateway (production)
- `npm run start:sse` - Run SSE gateway (explicit)
- `npm run start:ws` - Run WebSocket gateway
- `npm run start:streamable-http` - Run Streamable HTTP gateway

## Troubleshooting

**Server not starting:**
- Verify Node.js/npm installed: `node --version` and `npm --version`
- Check `.npmrc` has GitLab authentication configured
- Ensure package `@devops/kb-mcp-server` is accessible from GitLab Package Registry

**Connection issues:**
- Verify `KB_ENDPOINT` is accessible
- Test endpoint: `https://tools.benchmarkdigital.com/kb/callKBX.cfm?method=getType`
- Check authentication: JWT token may be required

**Authentication errors:**
- Verify GitLab token has `read_api` and `read_registry` scopes

## Agent Integration (Gateway Mode)

For integrating with AI agents (e.g., Strands Agents), the KB MCP server supports HTTP-based transports. **Streamable HTTP is the recommended transport** as it properly supports Authorization header pass-through.

### Starting the Gateway

```bash
# Streamable HTTP mode (recommended for agents)
npm run start:streamable-http

# SSE mode (via supergateway, legacy)
npm run start:sse

# WebSocket mode (via supergateway, legacy)
npm run start:ws
```

### Gateway Endpoints

| Transport | Endpoint | Health |
|-----------|----------|--------|
| Streamable HTTP (recommended) | `POST /mcp` | `GET /healthz` |
| SSE (legacy) | `GET /sse`, `POST /message` | `GET /healthz` |
| WebSocket (legacy) | `ws://host:8000/message` | `GET /healthz` |

### Authentication

**Every request must include an Authorization header with a valid JWT token.**

The token belongs to the end user making the request. Agents pass through user tokens - they don't authenticate themselves.

```bash
# Streamable HTTP - send MCP message
curl -X POST http://localhost:8000/mcp \
  -H "Authorization: Bearer <user-jwt>" \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "search_content",
      "arguments": {
        "query": "test"
      }
    }
  }'
```

The `Authorization: Bearer <JWT>` header is extracted and passed through to callKBX.cfm for user-level authentication.

### Strands Agent Integration

```python
from mcp.client.streamable_http import streamablehttp_client
from strands import Agent
from strands.tools.mcp import MCPClient

# Create MCP client with Streamable HTTP transport
kb_mcp_client = MCPClient(
    lambda: streamablehttp_client(
        url="http://localhost:8000/mcp",
        headers={"Authorization": f"Bearer {user_jwt}"}
    )
)

# Use with Strands Agent
with kb_mcp_client:
    tools = kb_mcp_client.list_tools_sync()
    agent = Agent(tools=tools)
    response = agent("Search for documentation about safety procedures")
```

**MCP URL vs KB URL:** The `url` above must be the **streamable HTTP gateway** (e.g. `http://localhost:8000/mcp` or your deployed gateway). Do **not** use the KB API endpoint (`https://tools.benchmarkdigital.com/kb/callKBX.cfm`). If the client is configured with the KB URL as base and appends `/mcp`, you will see incorrect requests to `.../callKBX.cfm/mcp`; that is a client/gateway configuration mistake, not something the MCP server generates.

### Gateway Configuration

Environment variables for gateway mode:

| Variable | Default | Description |
|----------|---------|-------------|
| `GATEWAY_TRANSPORT` | `sse` | Transport type: `sse`, `ws`, `streamableHttp` |
| `GATEWAY_PORT` | `8000` | Port to listen on |
| `GATEWAY_CORS` | `true` | Enable CORS for cross-origin requests |
| `GATEWAY_HEALTH_ENDPOINT` | `/healthz` | Health check endpoint path |
| `GATEWAY_LOG_LEVEL` | `info` | Logging: `debug`, `info`, `none` |
| `GATEWAY_SSE_PATH` | `/sse` | SSE subscription path |
| `GATEWAY_MESSAGE_PATH` | `/message` | Message endpoint path |
| `GATEWAY_STREAMABLE_HTTP_PATH` | `/mcp` | Streamable HTTP endpoint path |
| `GATEWAY_STATEFUL` | `false` | Stateful mode for Streamable HTTP |

### Docker Deployment

```bash
# Run in Streamable HTTP mode (recommended for agents)
docker run -p 8000:8000 -e SERVER_MODE=streamable-http kb-mcp-server

# Run in SSE gateway mode (legacy, via supergateway)
docker run -p 8000:8000 -e SERVER_MODE=sse kb-mcp-server

# Run in WebSocket gateway mode (legacy, via supergateway)
docker run -p 8000:8000 -e SERVER_MODE=ws kb-mcp-server
```

## Architecture

```
# Cursor Integration (stdio)
Cursor → MCP Server (stdio) → HTTP Request → callKBX.cfm → kbx.cfc → JSON Response

# Agent Integration (gateway)
Agent → Gateway (SSE/WS/HTTP) → supergateway → MCP Server (stdio) → HTTP Request → callKBX.cfm → kbx.cfc → JSON Response
```

