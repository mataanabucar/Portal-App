#!/bin/sh
# Docker entrypoint script for KB MCP Server
# Selects the appropriate server mode based on SERVER_MODE environment variable

set -e

# Environment variable takes precedence, then argument, then default to streamable-http
SERVER_MODE="${SERVER_MODE:-${1:-streamable-http}}"

echo "Starting KB MCP Server in ${SERVER_MODE} mode..."

case "$SERVER_MODE" in
  http)
    # REST API mode on port 3000
    exec node dist/http-server.js
    ;;
  stdio)
    # stdio transport (not typical for Docker, but supported)
    exec node dist/index.js
    ;;
  streamable-http)
    # Streamable HTTP MCP server on port 8000 (native implementation with auth header support)
    exec node dist/streamable-http-server.js
    ;;
  *)
    echo "Unknown SERVER_MODE: $SERVER_MODE"
    echo "Valid modes: http, stdio, streamable-http"
    exit 1
    ;;
esac
