# One-liner install script for KB MCP Server (PowerShell)
# Usage: irm https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.ps1 | iex

$ErrorActionPreference = "Stop"

Write-Host "KB MCP Server - Quick Install" -ForegroundColor Green
Write-Host "=============================" -ForegroundColor Green
Write-Host ""

# Check for npm
try {
    $null = Get-Command npm -ErrorAction Stop
} catch {
    Write-Host "✗ npm is required but not installed. Please install Node.js from https://nodejs.org/" -ForegroundColor Red
    exit 1
}

# Determine npmrc file location
$npmrcPath = if ($env:USERPROFILE) {
    Join-Path $env:USERPROFILE ".npmrc"
} else {
    Join-Path $env:HOME ".npmrc"
}

Write-Host "This script will help you:" -ForegroundColor Cyan
Write-Host "1. Create a GitLab Personal Access Token" -ForegroundColor White
Write-Host "2. Configure your .npmrc file at: $npmrcPath" -ForegroundColor White
Write-Host ""

# Open GitLab in browser
Write-Host "Step 1: Create GitLab Personal Access Token" -ForegroundColor Yellow
Write-Host "-------------------------------------------" -ForegroundColor Yellow
Write-Host "Opening GitLab Access Tokens page in your browser..." -ForegroundColor Cyan
Write-Host ""

$tokenUrl = "https://code.gensuite.com/-/user_settings/personal_access_tokens"
Start-Process $tokenUrl

Write-Host "In the browser that just opened:" -ForegroundColor Cyan
Write-Host "1. Enter a token name (e.g., 'KB MCP Server')" -ForegroundColor White
Write-Host "2. Set an expiration date (optional)" -ForegroundColor White
Write-Host "3. Select the following scopes:" -ForegroundColor White
Write-Host "   ✓ read_api" -ForegroundColor Green
Write-Host "   ✓ read_registry" -ForegroundColor Green
Write-Host "4. Click 'Create personal access token'" -ForegroundColor White
Write-Host "5. COPY THE TOKEN IMMEDIATELY (you won't see it again!)" -ForegroundColor Yellow
Write-Host ""

# Get token from user with validation loop
$tokenPlain = ""
while ($true) {
    # Use regular Read-Host instead of SecureString for better copy/paste compatibility
    $tokenInput = Read-Host "Paste your GitLab Personal Access Token here"
    $tokenPlain = $tokenInput

    if ([string]::IsNullOrWhiteSpace($tokenPlain)) {
        Write-Host "✗ Token is required. Please try again." -ForegroundColor Red
        continue
    }

    # Remove carriage returns (handle CRLF line endings)
    $tokenPlain = $tokenPlain -replace "`r", ""

    # Validate token format (GitLab personal access tokens: glpat- followed by 20 alphanumeric characters, underscores, or hyphens)
    if ($tokenPlain -match '^glpat-[0-9a-zA-Z_\-]{20}$') {
        break
    } else {
        Write-Host "✗ Invalid token format. GitLab personal access tokens should be in the format: glpat- followed by 20 alphanumeric characters, underscores, or hyphens" -ForegroundColor Red
        Write-Host "  Please try again." -ForegroundColor Yellow
    }
}

# Configure .npmrc
Write-Host ""
Write-Host "Step 2: Configuring .npmrc" -ForegroundColor Yellow
Write-Host "--------------------------" -ForegroundColor Yellow

$registryUrl = "https://code.gensuite.com/api/v4/packages/npm/"
$authTokenLine = "//code.gensuite.com/api/v4/packages/npm/:_authToken=$tokenPlain"

# Read existing .npmrc if it exists
$existingContent = ""
if (Test-Path $npmrcPath) {
    $existingContent = Get-Content $npmrcPath -Raw
    Write-Host "Found existing .npmrc file" -ForegroundColor Cyan
} else {
    Write-Host "Creating new .npmrc file" -ForegroundColor Cyan
}

# Check if @devops:registry already exists
$linesToAdd = @()
if ($existingContent -notmatch "@devops:registry=") {
    $linesToAdd += "@devops:registry=$registryUrl"
} else {
    Write-Host "Updating existing @devops:registry entry" -ForegroundColor Cyan
    $existingContent = $existingContent -replace "@devops:registry=.*", "@devops:registry=$registryUrl"
}

# Check if auth token already exists
if ($existingContent -notmatch "//code\.gensuite\.com/api/v4/packages/npm/:_authToken=") {
    $linesToAdd += $authTokenLine
} else {
    Write-Host "Updating existing auth token" -ForegroundColor Cyan
    $existingContent = $existingContent -replace "//code\.gensuite\.com/api/v4/packages/npm/:_authToken=.*", $authTokenLine
}

# Write to .npmrc
if ($linesToAdd.Count -gt 0) {
    if ($existingContent) {
        $existingContent += "`n" + ($linesToAdd -join "`n")
    } else {
        $existingContent = $linesToAdd -join "`n"
    }
}

# Ensure file ends with newline
if (-not $existingContent.EndsWith("`n")) {
    $existingContent += "`n"
}

Set-Content -Path $npmrcPath -Value $existingContent -NoNewline

Write-Host "✓ .npmrc file configured successfully!" -ForegroundColor Green
Write-Host ""
Write-Host "Configuration added to: $npmrcPath" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Open Cursor Settings (File > Preferences > Cursor Settings)" -ForegroundColor White
Write-Host "2. Navigate to Tools & MCP" -ForegroundColor White
Write-Host "3. Click + New MCP Server" -ForegroundColor White
Write-Host "4. Add the following configuration:" -ForegroundColor White
Write-Host ""
Write-Host @"
{
  "mcpServers": {
    "kb": {
      "command": "npx",
      "args": ["-y", "@devops/kb-mcp-server"]
    }
  }
}
"@ -ForegroundColor Gray
Write-Host ""
Write-Host 'Then restart Cursor and start using KB tools in conversations with "use kb;"' -ForegroundColor Green
Write-Host ""
