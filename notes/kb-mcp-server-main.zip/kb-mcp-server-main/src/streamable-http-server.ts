#!/usr/bin/env node

/**
 * Streamable HTTP MCP Server for KB Integration
 * 
 * This server implements the MCP Streamable HTTP transport for agent integration.
 * It extracts Authorization headers from incoming requests and passes them through
 * to the KB API for user-level authentication.
 * 
 * Endpoints:
 * - POST /mcp - Handle MCP requests (tool calls, initialization)
 * - GET /mcp - SSE stream for server-to-client notifications
 * - DELETE /mcp - Session termination
 * - GET /healthz - Health check
 * 
 * Authentication:
 * - Every request must include Authorization: Bearer <JWT> header
 * - The JWT is passed through to callKBX.cfm for user-level authentication
 */

import express, { Request, Response, NextFunction } from 'express';
import { randomUUID } from 'node:crypto';
import { AsyncLocalStorage } from 'node:async_hooks';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  isInitializeRequest,
} from '@modelcontextprotocol/sdk/types.js';
import { callKBMethod, KB_TOOLS, TOOL_METHOD_MAP, KB_SERVER_INSTRUCTIONS, config, handleGetUserBinders, handleListBinders, handleSearchBinderContent, handleGetTags } from './index-core.js';

// Configuration
const PORT = parseInt(process.env.GATEWAY_PORT || process.env.PORT || '8000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const MCP_PATH = process.env.GATEWAY_STREAMABLE_HTTP_PATH || '/mcp';
const HEALTH_ENDPOINT = process.env.GATEWAY_HEALTH_ENDPOINT || '/healthz';
const ENABLE_CORS = process.env.GATEWAY_CORS !== 'false';
const LOG_LEVEL = process.env.GATEWAY_LOG_LEVEL || 'info';

// AsyncLocalStorage to pass auth token to tool handlers
interface RequestContext {
  authToken: string | undefined;
  sessionId: string | undefined;
}
const requestContext = new AsyncLocalStorage<RequestContext>();

/**
 * Get the current auth token from request context
 */
export function getCurrentAuthToken(): string | undefined {
  return requestContext.getStore()?.authToken;
}

/**
 * Extract authentication token from Authorization header
 */
function extractAuthToken(req: Request): string | undefined {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return undefined;
  }
  
  // Support both "Bearer <token>" and just "<token>" formats
  if (authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  return authHeader;
}

/**
 * Log message based on log level
 */
function log(level: 'debug' | 'info' | 'error', message: string, ...args: any[]) {
  if (LOG_LEVEL === 'none') return;
  if (LOG_LEVEL === 'info' && level === 'debug') return;
  
  const timestamp = new Date().toISOString();
  const prefix = `[${timestamp}] [${level.toUpperCase()}]`;
  
  if (level === 'error') {
    console.error(prefix, message, ...args);
  } else {
    console.log(prefix, message, ...args);
  }
}

/**
 * Create and configure the MCP server with KB tools
 */
function createMcpServer(): Server {
  const server = new Server(
    {
      name: 'kb-mcp-server',
      version: '1.0.0',
    },
    {
      capabilities: {
        tools: {},
      },
      instructions: KB_SERVER_INSTRUCTIONS,
    }
  );

  // List available tools
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
      tools: KB_TOOLS,
    };
  });

  // Handle tool calls
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;

    try {
      // Get auth token from request context
      const authToken = getCurrentAuthToken();
      
      if (!authToken) {
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify({
                error: 'Authorization required',
                message: 'Please include Authorization: Bearer <JWT> header in your request',
              }),
            },
          ],
          isError: true,
        };
      }

      let result;

      if (name === 'call_method') {
        // Dynamic method call
        const method = args?.method as string;
        const params = (args?.params as Record<string, any>) || {};
        if (!method) {
          throw new Error('Method name is required');
        }
        result = await callKBMethod(method, params, authToken);
      } else if (name === 'get_content_url') {
        const contentid = args?.contentid as number;
        if (!contentid || typeof contentid !== 'number') {
          throw new Error('Content ID is required and must be a number');
        }
        const url = `https://tools.benchmarkdigital.com/kb/#content/${contentid}`;
        result = {
          url,
          contentid,
          message: `KB article URL: ${url}`,
        };
      } else if (name === 'get_user_binders') {
        result = await handleGetUserBinders(args || {}, authToken);
      } else if (name === 'list_binders') {
        result = await handleListBinders(args || {}, authToken);
      } else if (name === 'search_binder_content') {
        result = await handleSearchBinderContent(args || {}, authToken);
      } else if (name === 'get_tags') {
        result = await handleGetTags(args || {}, authToken);
      } else {
        // Map tool to KB method
        const kbMethod = TOOL_METHOD_MAP[name];
        if (!kbMethod) {
          throw new Error(`Unknown tool: ${name}`);
        }

        // Transform parameters for specific methods
        let methodParams = args ? { ...args } : {};

        // searchAsAgent uses 'rows' instead of 'limit', and 'start' for pagination
        if (kbMethod === 'searchAsAgent') {
          if (methodParams.limit !== undefined) {
            methodParams.rows = methodParams.limit;
            delete methodParams.limit;
          } else {
            methodParams.rows = 10;
          }

          if (methodParams.start === undefined) {
            methodParams.start = 0;
          }
        }

        result = await callKBMethod(kbMethod, methodParams, authToken);
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result, null, 2),
          },
        ],
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      return {
        content: [
          {
            type: 'text',
            text: `Error: ${errorMessage}`,
          },
        ],
        isError: true,
      };
    }
  });

  return server;
}

/**
 * Start the Streamable HTTP server
 */
async function startServer() {
  const app = express();
  app.use(express.json());

  // CORS middleware
  if (ENABLE_CORS) {
    app.use((req: Request, res: Response, next: NextFunction) => {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, mcp-session-id, last-event-id');
      res.header('Access-Control-Expose-Headers', 'mcp-session-id');

      if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
      }
      next();
    });
  }

  // Health check endpoint
  app.get(HEALTH_ENDPOINT, (req: Request, res: Response) => {
    res.status(200).json({
      status: 'healthy',
      service: 'kb-mcp-server',
      transport: 'streamable-http',
      timestamp: new Date().toISOString(),
    });
  });

  // Map to store transports and servers by session ID
  const sessions: Map<string, { transport: StreamableHTTPServerTransport; server: Server }> = new Map();

  // MCP endpoint - POST (client-to-server messages)
  app.post(MCP_PATH, async (req: Request, res: Response) => {
    const authToken = extractAuthToken(req);
    const sessionId = req.headers['mcp-session-id'] as string | undefined;

    log('debug', `POST ${MCP_PATH}`, {
      sessionId,
      hasAuth: !!authToken,
      method: req.body?.method,
    });

    try {
      let session = sessionId ? sessions.get(sessionId) : undefined;

      if (session) {
        // Existing session - run request in context with auth token
        await requestContext.run({ authToken, sessionId }, async () => {
          await session!.transport.handleRequest(req, res, req.body);
        });
      } else if (!sessionId && isInitializeRequest(req.body)) {
        // New initialization request - create new server and transport per session
        const server = createMcpServer();

        const transport = new StreamableHTTPServerTransport({
          sessionIdGenerator: () => randomUUID(),
          enableJsonResponse: true,
          onsessioninitialized: (newSessionId) => {
            log('info', `Session initialized: ${newSessionId}`);
            sessions.set(newSessionId, { transport, server });
          },
        });

        transport.onclose = () => {
          const sid = transport.sessionId;
          if (sid) {
            log('info', `Session closed: ${sid}`);
            sessions.delete(sid);
          }
        };

        await server.connect(transport);

        // Handle initialization request in context
        await requestContext.run({ authToken, sessionId: transport.sessionId }, async () => {
          await transport.handleRequest(req, res, req.body);
        });
      } else {
        log('error', 'Invalid request: No valid session ID or initialization request');
        res.status(400).json({
          jsonrpc: '2.0',
          error: {
            code: -32000,
            message: 'Bad Request: No valid session ID provided',
          },
          id: null,
        });
      }
    } catch (error) {
      log('error', 'Error handling MCP request:', error);
      if (!res.headersSent) {
        res.status(500).json({
          jsonrpc: '2.0',
          error: {
            code: -32603,
            message: 'Internal server error',
          },
          id: null,
        });
      }
    }
  });

  // MCP endpoint - GET (server-to-client SSE notifications)
  app.get(MCP_PATH, async (req: Request, res: Response) => {
    const authToken = extractAuthToken(req);
    const sessionId = req.headers['mcp-session-id'] as string | undefined;

    log('debug', `GET ${MCP_PATH} (SSE)`, { sessionId, hasAuth: !!authToken });

    try {
      if (!sessionId) {
        res.status(400).send('Missing session ID');
        return;
      }

      const session = sessions.get(sessionId);
      if (!session) {
        res.status(400).send('Invalid session ID');
        return;
      }

      await requestContext.run({ authToken, sessionId }, async () => {
        await session.transport.handleRequest(req, res);
      });
    } catch (error) {
      log('error', 'Error handling SSE request:', error);
      if (!res.headersSent) {
        res.status(500).send('Internal server error');
      }
    }
  });

  // MCP endpoint - DELETE (session termination)
  app.delete(MCP_PATH, async (req: Request, res: Response) => {
    const sessionId = req.headers['mcp-session-id'] as string | undefined;

    log('debug', `DELETE ${MCP_PATH}`, { sessionId });

    try {
      if (!sessionId) {
        res.status(400).send('Missing session ID');
        return;
      }

      const session = sessions.get(sessionId);
      if (!session) {
        res.status(400).send('Invalid session ID');
        return;
      }

      await session.transport.handleRequest(req, res);
    } catch (error) {
      log('error', 'Error handling DELETE request:', error);
      if (!res.headersSent) {
        res.status(500).send('Error processing session termination');
      }
    }
  });

  // Start listening
  const server = app.listen(PORT, HOST, () => {
    console.log('');
    console.log('KB MCP Streamable HTTP Server');
    console.log('=============================');
    console.log(`Listening on http://${HOST}:${PORT}`);
    console.log(`MCP endpoint: POST/GET/DELETE ${MCP_PATH}`);
    console.log(`Health check: GET ${HEALTH_ENDPOINT}`);
    console.log(`CORS: ${ENABLE_CORS ? 'enabled' : 'disabled'}`);
    console.log(`Log level: ${LOG_LEVEL}`);
    console.log('');
    console.log('KB Configuration:');
    console.log(`  Endpoint: ${config.endpoint}`);
    console.log(`  Max concurrent requests: ${config.maxConcurrentRequests}`);
    console.log(`  Request queue timeout: ${config.requestQueueTimeout}ms`);
    console.log('');
    console.log('Authentication:');
    console.log('  Every request must include Authorization: Bearer <JWT> header');
    console.log('  The JWT is passed through to the KB API for user-level auth');
    console.log('');
  });

  // Graceful shutdown
  const shutdown = async (signal: string) => {
    console.log(`\n${signal} received, shutting down...`);

    // Close all sessions
    for (const [sessionId, session] of sessions) {
      try {
        log('info', `Closing session ${sessionId}`);
        await session.transport.close();
        await session.server.close();
      } catch (error) {
        log('error', `Error closing session ${sessionId}:`, error);
      }
    }
    sessions.clear();

    server.close(() => {
      console.log('Server shutdown complete');
      process.exit(0);
    });

    // Force exit after timeout
    const timeout = global.setTimeout(() => {
      console.log('Force shutdown after timeout');
      process.exit(1);
    }, 5000);
    timeout.unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Start server
startServer().catch((error) => {
  console.error('Fatal error starting server:', error);
  process.exit(1);
});
