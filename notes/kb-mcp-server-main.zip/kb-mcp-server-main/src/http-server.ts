#!/usr/bin/env node

/**
 * HTTP Server Adapter for KB MCP Server
 * 
 * This HTTP server exposes the KB MCP functionality via REST API
 * for deployment in containerized environments like AWS ECS.
 * 
 * It handles concurrent requests using Node.js's built-in async capabilities
 * and can be scaled horizontally across multiple ECS tasks.
 */

import { createServer, IncomingMessage, ServerResponse } from 'http';
import { URL } from 'url';
import { callKBMethod, KB_TOOLS, TOOL_METHOD_MAP, handleGetUserBinders, handleListBinders, handleSearchBinderContent, handleGetTags } from './index-core.js';

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';

interface HTTPRequest {
  method: string;
  url: string;
  headers: Record<string, string | string[] | undefined>;
  body?: any;
}

/**
 * Parse request body
 */
async function parseBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (error) {
        reject(new Error('Invalid JSON in request body'));
      }
    });
    req.on('error', reject);
  });
}

/**
 * Send JSON response
 */
function sendJSON(res: ServerResponse, statusCode: number, data: any) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  });
  res.end(JSON.stringify(data));
}

/**
 * Handle CORS preflight
 */
function handleCORS(res: ServerResponse) {
  res.writeHead(200, {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Max-Age': '86400',
  });
  res.end();
}

/**
 * Health check endpoint
 */
function handleHealthCheck(res: ServerResponse) {
  sendJSON(res, 200, {
    status: 'healthy',
    service: 'kb-mcp-server',
    timestamp: new Date().toISOString(),
  });
}

/**
 * List available tools
 */
function handleListTools(res: ServerResponse) {
  sendJSON(res, 200, {
    tools: KB_TOOLS,
  });
}

/**
 * Extract authentication token from Authorization header
 */
function extractAuthToken(headers: Record<string, string | string[] | undefined>): string | undefined {
  const authHeader = headers.authorization || headers.Authorization;
  if (!authHeader) {
    return undefined;
  }

  const authValue = Array.isArray(authHeader) ? authHeader[0] : authHeader;

  if (authValue.startsWith('Bearer ')) {
    return authValue.substring(7);
  }
  return authValue;
}

/**
 * Handle tool execution
 */
async function handleToolCall(req: HTTPRequest, res: ServerResponse) {
  try {
    const { name, arguments: args } = req.body;

    if (!name) {
      sendJSON(res, 400, {
        error: 'Tool name is required',
      });
      return;
    }

    // Extract authentication token from request headers
    const authToken = extractAuthToken(req.headers);

    if (!authToken) {
      sendJSON(res, 401, {
        error: 'Authorization required. Please provide a JWT via the Authorization header (Bearer <token>)',
      });
      return;
    }

    let result;

    if (name === 'call_method') {
      // Dynamic method call
      const method = args?.method as string;
      const params = (args?.params as Record<string, any>) || {};
      if (!method) {
        throw new Error('Method name is required');
      }
      result = await callKBMethod(method, params, authToken);
    } else if (name === 'get_content_url') {
      // Generate URL for KB content (no API call needed)
      const contentid = args?.contentid as number;
      if (!contentid || typeof contentid !== 'number') {
        throw new Error('Content ID is required and must be a number');
      }
      const url = `https://tools.benchmarkdigital.com/kb/#content/${contentid}`;
      result = {
        url,
        contentid,
        message: `KB article URL: ${url}`,
      };
    } else if (name === 'get_user_binders') {
      result = await handleGetUserBinders(args || {}, authToken);
    } else if (name === 'list_binders') {
      result = await handleListBinders(args || {}, authToken);
    } else if (name === 'search_binder_content') {
      result = await handleSearchBinderContent(args || {}, authToken);
    } else if (name === 'get_tags') {
      result = await handleGetTags(args || {}, authToken);
    } else {
      // Map tool to KB method
      const kbMethod = TOOL_METHOD_MAP[name];
      if (!kbMethod) {
        throw new Error(`Unknown tool: ${name}`);
      }

      // Transform parameters for specific methods
      let methodParams = args || {};

      // searchAsAgent uses 'rows' instead of 'limit', and 'start' for pagination
      if (kbMethod === 'searchAsAgent') {
        methodParams = { ...methodParams };

        if (methodParams.limit !== undefined) {
          methodParams.rows = methodParams.limit;
          delete methodParams.limit;
        } else {
          methodParams.rows = 10;
        }

        if (methodParams.start === undefined) {
          methodParams.start = 0;
        }
      }

      result = await callKBMethod(kbMethod, methodParams, authToken);
    }

    sendJSON(res, 200, {
      success: true,
      data: result,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    sendJSON(res, 500, {
      success: false,
      error: errorMessage,
    });
  }
}

/**
 * Main request handler
 */
async function requestHandler(req: IncomingMessage, res: ServerResponse) {
  const url = new URL(req.url || '/', `http://${req.headers.host}`);
  const path = url.pathname;

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    handleCORS(res);
    return;
  }

  // Health check
  if (path === '/health' || path === '/healthz') {
    handleHealthCheck(res);
    return;
  }

  // List tools
  if (path === '/tools' && req.method === 'GET') {
    handleListTools(res);
    return;
  }

  // Execute tool
  if (path === '/call' && req.method === 'POST') {
    const body = await parseBody(req);

    // Convert headers to a plain object for easier access
    const headers: Record<string, string | string[] | undefined> = {};
    for (const [key, value] of Object.entries(req.headers)) {
      headers[key] = value;
    }

    await handleToolCall(
      {
        method: req.method || 'POST',
        url: req.url || '/',
        headers,
        body,
      },
      res
    );
    return;
  }

  // Root endpoint - API info
  if (path === '/' && req.method === 'GET') {
    sendJSON(res, 200, {
      service: 'KB MCP Server HTTP Adapter',
      version: '1.0.0',
      endpoints: {
        health: 'GET /health',
        listTools: 'GET /tools',
        callTool: 'POST /call',
      },
      authentication: {
        required: true,
        method: 'Authorization header',
        format: 'Bearer <JWT> or just <JWT>',
        note: 'Each user must provide their own JWT in the Authorization header for all /call requests',
      },
    });
    return;
  }

  // 404
  sendJSON(res, 404, {
    error: 'Not found',
    path,
  });
}

/**
 * Start HTTP server
 */
function startServer() {
  const server = createServer(requestHandler);

  server.listen(PORT, HOST, () => {
    console.log(`KB MCP HTTP Server running on http://${HOST}:${PORT}`);
    console.log(`Health check: http://${HOST}:${PORT}/health`);
    console.log(`List tools: http://${HOST}:${PORT}/tools`);
    console.log(`Call tool: POST http://${HOST}:${PORT}/call`);
  });

  server.on('error', (error: Error) => {
    console.error('Server error:', error);
    process.exit(1);
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully...');
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  });

  process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully...');
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  });
}

// Start server
startServer();
