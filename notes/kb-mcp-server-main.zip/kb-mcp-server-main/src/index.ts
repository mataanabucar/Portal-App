#!/usr/bin/env node

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { callKBMethod, KB_TOOLS, TOOL_METHOD_MAP, KB_SERVER_INSTRUCTIONS, handleGetUserBinders, handleListBinders, handleSearchBinderContent, handleGetTags, fetchTokenOnStartup, config } from "./index-core.js";

/**
 * MCP Server for Knowledge Base (KB) Integration (stdio mode)
 * 
 * This server provides tools to interact with the KB system through callKBX.cfm
 * which acts as a gateway to kbx.cfc methods.
 * 
 * For HTTP/ECS deployment, use http-server.ts instead.
 */

/**
 * Create and configure the MCP server
 */
const server = new Server(
  {
    name: "kb-mcp-server",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
    instructions: KB_SERVER_INSTRUCTIONS,
  }
);

// List available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: KB_TOOLS,
  };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    let result;

    if (name === "call_method") {
      // Dynamic method call
      const method = args?.method as string;
      const params = (args?.params as Record<string, any>) || {};
      if (!method) {
        throw new Error("Method name is required");
      }
      result = await callKBMethod(method, params);
    } else if (name === "get_content_url") {
      const contentid = args?.contentid as number;
      if (!contentid || typeof contentid !== "number") {
        throw new Error("Content ID is required and must be a number");
      }
      const url = `https://tools.benchmarkdigital.com/kb/#content/${contentid}`;
      result = {
        url,
        contentid,
        message: `KB article URL: ${url}`,
      };
    } else if (name === "get_user_binders") {
      result = await handleGetUserBinders(args || {});
    } else if (name === "list_binders") {
      result = await handleListBinders(args || {});
    } else if (name === "search_binder_content") {
      result = await handleSearchBinderContent(args || {});
    } else if (name === "get_tags") {
      result = await handleGetTags(args || {});
    } else {
      // Map tool to KB method
      const kbMethod = TOOL_METHOD_MAP[name];
      if (!kbMethod) {
        throw new Error(`Unknown tool: ${name}`);
      }
      
      // Transform parameters for specific methods
      let methodParams = args || {};
      
      // searchAsAgent uses 'rows' instead of 'limit', and 'start' for pagination
      if (kbMethod === "searchAsAgent") {
        methodParams = { ...methodParams };
        
        // Map 'limit' to 'rows' with default of 10
        if (methodParams.limit !== undefined) {
          methodParams.rows = methodParams.limit;
          delete methodParams.limit;
        } else {
          methodParams.rows = 10; // Default rows
        }
        
        // Ensure 'start' has a default value of 0 if not provided
        if (methodParams.start === undefined) {
          methodParams.start = 0; // Default start
        }
      }
      
      result = await callKBMethod(kbMethod, methodParams);
    }

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(result, null, 2),
        },
      ],
    };
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : String(error);
    return {
      content: [
        {
          type: "text",
          text: `Error: ${errorMessage}`,
        },
      ],
      isError: true,
    };
  }
});

/**
 * Start the server
 */
async function main() {
  console.error("KB MCP Server: Starting...");

  // Attempt to automatically fetch JWT token on startup if not provided
  const fetchedToken = await fetchTokenOnStartup();

  if (fetchedToken) {
    console.error("KB MCP Server: Automatically retrieved JWT token");
  } else if (!config.authToken) {
    console.error("KB MCP Server: No JWT token found. Set KB_AUTH_TOKEN environment variable or complete browser authentication.");
  }

  const transport = new StdioServerTransport();
  await server.connect(transport);

  console.error("KB MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});

