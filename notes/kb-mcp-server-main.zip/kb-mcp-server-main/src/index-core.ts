/**
 * Core KB MCP Server Logic (Shared between stdio and HTTP modes)
 *
 * This module contains the core functionality that can be used
 * by both the stdio server (index.ts) and HTTP server (http-server.ts)
 */

import {
  Tool,
} from "@modelcontextprotocol/sdk/types.js";
import { exec } from "child_process";
import { promisify } from "util";
import { readFile, writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { homedir } from "os";

const execAsync = promisify(exec);

/**
 * Semaphore for limiting concurrent KB API requests
 * Implements a hybrid queue-with-timeout pattern:
 * - Requests within limit execute immediately
 * - Excess requests queue and wait for a slot
 * - Requests waiting too long are rejected with an error
 */
class Semaphore {
  private permits: number;
  private maxPermits: number;
  private queue: Array<{ resolve: () => void; reject: (err: Error) => void; timer: NodeJS.Timeout }> = [];

  constructor(permits: number) {
    this.permits = permits;
    this.maxPermits = permits;
  }

  async acquire(timeoutMs: number): Promise<void> {
    if (this.permits > 0) {
      this.permits--;
      return;
    }

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const idx = this.queue.findIndex(e => e.timer === timer);
        if (idx !== -1) {
          this.queue.splice(idx, 1);
          reject(new Error(`KB API concurrency limit reached (${this.maxPermits} max). Request waited ${timeoutMs}ms in queue.`));
        }
      }, timeoutMs);

      this.queue.push({ resolve, reject, timer });
    });
  }

  release(): void {
    const entry = this.queue.shift();
    if (entry) {
      clearTimeout(entry.timer);
      entry.resolve();
    } else {
      this.permits++;
    }
  }

  getStats(): { available: number; queued: number; max: number } {
    return { available: this.permits, queued: this.queue.length, max: this.maxPermits };
  }
}

export interface KBConfig {
  endpoint: string;
  authToken?: string;
  cfAccessClientId?: string;
  cfAccessClientSecret?: string;
  cookies?: string;
  maxConcurrentRequests: number;
  requestQueueTimeout: number;
}

export interface KBResponse {
  success?: boolean;
  data?: any;
  errors?: any[];
  message?: string;
}

// Default configuration - can be overridden via environment variables
export const config: KBConfig = {
  endpoint: process.env.KB_ENDPOINT || "https://tools.benchmarkdigital.com/kb/callKBX.cfm",
  authToken: process.env.KB_AUTH_TOKEN,
  cfAccessClientId: process.env.KB_CF_ACCESS_CLIENT_ID,
  cfAccessClientSecret: process.env.KB_CF_ACCESS_CLIENT_SECRET,
  cookies: process.env.KB_COOKIES,
  maxConcurrentRequests: parseInt(process.env.KB_MAX_CONCURRENT_REQUESTS || '50', 10),
  requestQueueTimeout: parseInt(process.env.KB_REQUEST_QUEUE_TIMEOUT || '30000', 10),
};

// Semaphore for limiting concurrent KB API requests
const kbSemaphore = new Semaphore(config.maxConcurrentRequests);

// Export for monitoring/debugging
export function getKBSemaphoreStats() {
  return kbSemaphore.getStats();
}

/**
 * Get the path to the token storage file
 * Stores token in user's home directory under .kb-mcp-server/token
 */
function getTokenFilePath(): string {
  const tokenDir = join(homedir(), ".kb-mcp-server");
  return join(tokenDir, "token");
}

/**
 * Read JWT token from persistent storage file
 */
async function readTokenFromFile(): Promise<string | undefined> {
  try {
    const tokenPath = getTokenFilePath();
    const token = await readFile(tokenPath, "utf-8");
    return token.trim() || undefined;
  } catch (error) {
    return undefined;
  }
}

/**
 * Write JWT token to persistent storage file
 */
async function writeTokenToFile(token: string): Promise<void> {
  try {
    const tokenPath = getTokenFilePath();
    const tokenDir = join(homedir(), ".kb-mcp-server");
    await mkdir(tokenDir, { recursive: true });
    await writeFile(tokenPath, token.trim(), { mode: 0o600 });
  } catch (error) {
    console.error("KB MCP Server: Failed to persist token to file:", error instanceof Error ? error.message : String(error));
  }
}

/**
 * Automatically fetch JWT token on startup.
 * Priority: 1) Environment variable, 2) Persistent file, 3) Simple fetch, 4) Puppeteer browser
 */
export async function fetchTokenOnStartup(tokenEndpoint?: string): Promise<string | undefined> {
  if (config.authToken) {
    return config.authToken;
  }

  const fileToken = await readTokenFromFile();
  if (fileToken) {
    config.authToken = fileToken;
    console.error("KB MCP Server: Loaded JWT token from persistent storage");
    return fileToken;
  }

  const endpoint = tokenEndpoint || process.env.KB_TOKEN_ENDPOINT || "https://tools.benchmarkdigital.com/kb/callKBX.cfm?method=getMCPAuthToken";

  // Try a simple fetch first (works if user has an existing session)
  try {
    const headers: Record<string, string> = {};
    if (config.cookies) {
      headers["Cookie"] = config.cookies;
    }
    if (config.cfAccessClientId) {
      headers["CF-Access-Client-Id"] = config.cfAccessClientId;
    }
    if (config.cfAccessClientSecret) {
      headers["CF-Access-Client-Secret"] = config.cfAccessClientSecret;
    }

    const response = await fetch(endpoint, { method: "GET", headers });

    if (response.ok) {
      const contentType = response.headers.get("content-type") || "";
      const responseText = await response.text();

      if (!contentType.includes("text/html") && !responseText.trim().startsWith("<")) {
        try {
          const data = JSON.parse(responseText);
          const tokenData = data.data || data;
          if (tokenData && typeof tokenData.token === "string") {
            const token = tokenData.token;
            config.authToken = token;
            await writeTokenToFile(token);
            return token;
          }
        } catch (parseError) {
          // Not JSON, continue to browser approach
        }
      }
    }
  } catch (error) {
    // Fetch failed, continue to browser approach
  }

  // If fetch didn't work, try using Puppeteer for interactive authentication
  try {
    let puppeteer: typeof import("puppeteer");
    try {
      puppeteer = await import("puppeteer");
    } catch (importError) {
      return undefined;
    }

    const isCursorEnv = !!(process.env.CURSOR || process.env.VSCODE || process.env.CODESPACES);
    const useHeadless: boolean = isCursorEnv || process.env.KB_USE_HEADLESS_BROWSER === "true";

    const browser = await puppeteer.launch({
      headless: useHeadless,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });

    try {
      const page = await browser.newPage();

      if (useHeadless) {
        console.error(`KB MCP Server: Opening authentication URL in your default browser...`);
        console.error(`KB MCP Server: ${endpoint}`);
        console.error("KB MCP Server: Please complete authentication, then the token will be retrieved automatically.");

        try {
          const platform = process.platform;
          let command: string;
          if (platform === "win32") {
            command = `start "" "${endpoint}"`;
          } else if (platform === "darwin") {
            command = `open "${endpoint}"`;
          } else {
            command = `xdg-open "${endpoint}"`;
          }
          await execAsync(command);
        } catch (openError) {
          console.error(`KB MCP Server: Please manually open: ${endpoint}`);
        }
      } else {
        console.error(`KB MCP Server: Opening browser for authentication at ${endpoint}`);
        console.error("KB MCP Server: Please complete authentication in the browser window...");
      }

      const response = await page.goto(endpoint, {
        waitUntil: "networkidle2",
        timeout: 60000,
      });

      if (!response) {
        return undefined;
      }

      let token: string | undefined;

      try {
        const tokenData = await page.waitForFunction(
          () => {
            // @ts-expect-error - document exists in browser context
            const bodyText = document.body?.textContent || document.body?.innerText || "";
            try {
              const jsonMatch = bodyText.match(/\{[\s\S]*"token"[\s\S]*\}/);
              if (jsonMatch) {
                const data = JSON.parse(jsonMatch[0]);
                const tokenData = data.data || data;
                if (tokenData && typeof tokenData.token === "string") {
                  return tokenData.token;
                }
              }
              if (bodyText.trim().startsWith("{")) {
                const data = JSON.parse(bodyText.trim());
                const tokenData = data.data || data;
                if (tokenData && typeof tokenData.token === "string") {
                  return tokenData.token;
                }
              }
            } catch (e) {
              // Not valid JSON yet
            }
            return null;
          },
          {
            timeout: 600000, // 10 minutes max wait
            polling: 500,
          }
        );

        token = (await tokenData.jsonValue()) as string;
      } catch (waitError) {
        console.error("KB MCP Server: Could not retrieve token. Please ensure you completed authentication.");
        return undefined;
      }

      if (token) {
        config.authToken = token;
        await writeTokenToFile(token);
        console.error("KB MCP Server: Successfully retrieved JWT token from browser and saved to persistent storage");
        return token;
      }

      return undefined;
    } finally {
      await browser.close();
    }
  } catch (error) {
    return undefined;
  }
}

/**
 * Call a KB method via HTTP request to callKBX.cfm
 *
 * Uses POST for methods with large payloads (like saveContent) and GET for others.
 * callKBX.cfm accepts parameters from both URL and FORM scopes.
 */
export async function callKBMethod(
  method: string,
  params: Record<string, any> = {},
  authToken?: string
): Promise<any> {
  // Acquire semaphore slot (queue with timeout if at capacity)
  await kbSemaphore.acquire(config.requestQueueTimeout);

  // Methods that typically have large content should use POST
  const usePostMethods = ["saveContent", "saveContentToS3", "createS3ContentObject", "searchIndexES", "searchAsAgent"];
  const usePost = usePostMethods.includes(method) ||
                  Object.keys(params).some(key =>
                    key === "content" && typeof params[key] === "string" && params[key].length > 1000
                  );

  // searchIndexES and searchAsAgent expect the query parameter to be base64-encoded
  if ((method === "searchIndexES" || method === "searchAsAgent") && params.query && typeof params.query === "string") {
    params = { ...params, query: Buffer.from(params.query, "utf8").toString("base64") };
  }

  // saveContent expects the content parameter to be base64-encoded
  // IMPORTANT: Content must be provided as HTML (Markdown is not supported by the KB system)
  // The server automatically encodes HTML content to base64 before transmission
  if ((method === "saveContent" || method === "saveContentToS3") && params.content && typeof params.content === "string") {
    params = { ...params, content: Buffer.from(params.content, "utf8").toString("base64") };
  }

  const headers: Record<string, string> = {};

  const effectiveAuthToken = authToken || config.authToken;
  if (effectiveAuthToken) {
    headers["Authorization"] = `Bearer ${effectiveAuthToken}`;
  }

  // Add cookies if configured (for session-based authentication)
  if (config.cookies) {
    headers["Cookie"] = config.cookies;
  }

  // Add Cloudflare Access headers if configured
  if (config.cfAccessClientId) {
    headers["CF-Access-Client-Id"] = config.cfAccessClientId;
  }
  if (config.cfAccessClientSecret) {
    headers["CF-Access-Client-Secret"] = config.cfAccessClientSecret;
  }

  let response: Response;

  // Debug logging for gateway mode
  if (process.env.GATEWAY_MODE === 'true' && process.env.DEBUG_REQUESTS === 'true') {
    console.error(`KB API Request: method=${method}, endpoint=${config.endpoint}`);
    console.error(`KB API Headers: Authorization=${headers.Authorization ? 'Bearer <' + (headers.Authorization as string).length + ' chars>' : 'NOT SET'}`);
    console.error(`KB API Token provided: ${effectiveAuthToken ? 'yes (' + effectiveAuthToken.length + ' chars)' : 'NO'}`);
  }

  try {
    if (usePost) {
      // Use POST with form-encoded data (callKBX.cfm reads from FORM scope)
      headers["Content-Type"] = "application/x-www-form-urlencoded";

      const formData = new URLSearchParams();
      formData.set("method", method);

      for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null) {
          formData.set(key, String(value));
        }
      }

      response = await fetch(config.endpoint, {
        method: "POST",
        headers,
        body: formData.toString(),
      });
    } else {
      // Use GET with query parameters
      const url = new URL(config.endpoint);
      url.searchParams.set("method", method);

      for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null) {
          url.searchParams.set(key, String(value));
        }
      }

      response = await fetch(url.toString(), {
        method: "GET",
        headers,
      });
    }

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(
        `HTTP error! status: ${response.status}, statusText: ${response.statusText}, body: ${errorText}`
      );
    }

    // Check if response is HTML (likely an authentication redirect)
    const contentType = response.headers.get("content-type") || "";
    const responseText = await response.text();

    if (contentType.includes("text/html") || responseText.trim().startsWith("<")) {
      throw new Error(
        `Received HTML response instead of JSON. This usually indicates an authentication issue or redirect. Response: ${responseText.substring(0, 200)}`
      );
    }

    let data: KBResponse;
    try {
      data = JSON.parse(responseText) as KBResponse;
    } catch (parseError) {
      throw new Error(
        `Failed to parse JSON response. Content-Type: ${contentType}, Response: ${responseText.substring(0, 200)}`
      );
    }

    // Handle the response structure from callKBX.cfm
    if (data.success === false) {
      const errorDetails = data.errors && data.errors.length > 0
        ? JSON.stringify(data.errors)
        : data.message || "KB method call failed";
      throw new Error(errorDetails);
    }

    return data.data || data;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error(`Failed to call KB method: ${String(error)}`);
  } finally {
    // Always release the semaphore slot
    kbSemaphore.release();
  }
}

/**
 * Get user binders with optional client-side name filtering.
 * The backend getUserBinders() does not support name filtering,
 * so we fetch all binders and filter in the MCP server.
 */
export async function handleGetUserBinders(
  args: Record<string, any>,
  authToken?: string
): Promise<any> {
  const result = await callKBMethod("getUserBinders", {}, authToken);

  const nameFilter = args?.name as string | undefined;
  if (!nameFilter) {
    return result;
  }

  const filterLower = nameFilter.toLowerCase();

  if (Array.isArray(result)) {
    return result.filter((binder: any) => {
      const binderName = (binder.name || binder.NAME || "").toLowerCase();
      return binderName.includes(filterLower);
    });
  }

  // Handle column-based CF query format
  if (result && typeof result === "object" && (result.COLUMNS || result.columns)) {
    const columns: string[] = result.COLUMNS || result.columns || [];
    const data: any[][] = result.DATA || result.data || [];
    const nameIdx = columns.findIndex(
      (c: string) => c.toUpperCase() === "NAME"
    );
    if (nameIdx >= 0) {
      return {
        ...result,
        DATA: data.filter((row: any[]) =>
          String(row[nameIdx]).toLowerCase().includes(filterLower)
        ),
      };
    }
  }

  return result;
}

/**
 * List binders with optional filtering.
 * Calls getBinders which returns all non-archived binders,
 * with optional orgid, ownerid, name (LIKE), and subscribed filters.
 */
export async function handleListBinders(
  args: Record<string, any>,
  authToken?: string
): Promise<any> {
  const params: Record<string, any> = {};
  if (args?.orgid) params.orgid = args.orgid;
  if (args?.ownerid) params.ownerid = args.ownerid;
  if (args?.name) params.name = args.name;
  if (args?.subscribed) params.subscribed = args.subscribed;

  return await callKBMethod("getBinders", params, authToken);
}

/**
 * Search within a specific binder using the ES binderids filter.
 * Uses searchAsAgent with the binderids must-filter for server-side filtering.
 */
export async function handleSearchBinderContent(
  args: Record<string, any>,
  authToken?: string
): Promise<any> {
  const binderid = args.binderid as number;
  const query = args.query as string;
  const limit = (args.limit as number) || 10;

  if (!binderid) {
    throw new Error("binderid is required");
  }
  if (!query) {
    throw new Error("query is required");
  }

  const searchResult = await callKBMethod("searchAsAgent", {
    query,
    rows: limit,
    start: 0,
    binderids: String(binderid),
  }, authToken);

  const fileContent = searchResult?.Filecontent || searchResult?.filecontent || searchResult;
  const hits: any[] = fileContent?.hits?.hits || [];
  const totalHits = fileContent?.hits?.total?.value || hits.length;

  return {
    binderid,
    query,
    matched_results: totalHits,
    returned_results: hits.length,
    results: hits,
  };
}

/**
 * Get tags with optional tag type filtering.
 * Routes to getTagsOfTagType when tagtypeid is provided (supports tag type filtering),
 * or getTag when no tagtypeid is given (returns all tags from kbx_tag).
 */
export async function handleGetTags(
  args: Record<string, any>,
  authToken?: string
): Promise<any> {
  if (args?.tagtypeid) {
    return await callKBMethod("getTagsOfTagType", { tagtypeid: args.tagtypeid }, authToken);
  }
  return await callKBMethod("getTag", {}, authToken);
}

/**
 * Server instructions exported for MCP server initialization.
 * Provides agents with the KB data model, ID relationships, permissions, and workflows.
 */
export const KB_SERVER_INSTRUCTIONS = `KB (Knowledge Base) MCP Server — Tools for managing KB content and binders.

CONTENT MODEL:
- KB CONTENT (identified by contentid) are standalone articles with a title, HTML body, type, and tags.
- Content is created/updated via save_content, searched via search_content, and retrieved via get_content.
- Content must be HTML (not Markdown). The server base64-encodes it automatically.
- Search filters (tags, pillars, users, owners, binderids) use pipe '|' separators, not commas.

BINDER DATA MODEL:
Binders are curated collections that organize KB content into a hierarchical structure.

Key concepts:
- A BINDER (identified by binderid/binderID) is the top-level container. It has a name, description, visibility (public/private), and an owner (user or organization).
- A binder contains SECTIONS (identified by sectionid/sectionID). Each section is a row in the binder's content tree and can be one of:
  - FOLDER (isfolder=1): A container that holds child sections. Folders can nest.
  - ARTICLE LINK (contentid set): A reference to a KB content article by its contentid.
  - EXTERNAL LINK (extlink set): A URL to an external resource.
  - SHORTCUT (shortcutid set): A reference to another section within the binder.
  Only one link type (contentid, extlink, shortcutid) can be set per section.
- Sections have a parentid (the folder they belong to, or null/0 for root-level items) and a sortorder for positioning within their parent.

ID RELATIONSHIPS:
- binderid: Identifies a binder. Obtained from get_user_binders, list_binders, or insert_binder.
- sectionid: Identifies an item within a binder's content tree. Obtained from get_binder_contents or insert_binder_content.
- contentid: Identifies a KB article (separate from binders). A single article can appear in multiple binders. Use get_binder_ids_for_content to find which binders contain a given article.

PERMISSIONS:
- ADMIN ("Binder Admin" tag): Can update binder metadata (name, description, visibility), manage admin/editor assignments, and archive the binder.
- EDITOR ("Binder Edit" tag): Can add, update, reorder, and archive sections within the binder.
- Organization-level permissions may also grant admin/editor access based on the user's band level within their org.
- Use get_binder_permissions to check the current user's access before write operations.

TYPICAL WORKFLOWS:
1. Browse binders: get_user_binders → get_binder_contents (to see the content tree)
2. Create & populate: insert_binder → insert_binder_content (add articles/folders/links)
3. Reorganize: update_binder_content_rank (reorder) or move_binder_content_to_root
4. Search within binder: search_binder_content
5. Check access: get_binder_permissions
6. Find article locations: get_binder_ids_for_content
`;

/**
 * List of available KB tools with descriptions
 */
export const KB_TOOLS: Tool[] = [
  {
    name: "get_content",
    description: "Get a KB article by its contentid. Returns full article details including title, HTML content body, type, tags, author, dates, and action history. Use search_content or find_content_by_title to discover content IDs. The contentid returned here is also what you pass to insert_binder_content to add an article to a binder.",
    inputSchema: {
      type: "object",
      properties: {
        contentid: {
          type: "number",
          description: "The content ID of the KB article to retrieve. Obtain from search_content, find_content_by_title, get_recent_content, or get_binder_contents.",
        },
        columns: {
          type: "string",
          description: "Comma-separated list of columns to return (optional). Omit to get all columns. Available columns include: contentid, title, content, typeid, archived, createdate, etc.",
        },
        actiontypes: {
          type: "string",
          description: "Comma-separated action types to include in history (optional). Values: 'create', 'update', 'view', 'archive', 'favorite', 'showcase', 'upvote', 'downvote', 'clearvote', 'followup', 'subscription'.",
        },
      },
      required: ["contentid"],
    },
  },
  {
    name: "search_content",
    description: "Full-text search across all KB content using Elasticsearch (uses searchAsAgent — optimized for agents with higher semantic vector weight 0.7 and lean response fields: originid, title, content, tags, pillartags, authorid, ownerid, lastmodified, binderids). This is the primary way to discover content — use get_content to retrieve full details for a specific result. For searching within a single binder, prefer search_binder_content instead. Supports pagination via start/limit. Supports advanced search syntax: use + for required terms, - for excluded terms, \"quotes\" for exact phrases, * for wildcards, ~ for fuzzy matching.",
    inputSchema: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description: "Search query string. Supports full-text search across article titles and content bodies. Supports advanced syntax: +required -excluded \"exact phrase\" wildcard* ~fuzzy.",
        },
        limit: {
          type: "number",
          description: "Maximum number of results to return (default: 10). Maps to 'rows' parameter internally.",
        },
        start: {
          type: "number",
          description: "Starting record number for pagination (default: 0). Use 0 for first page; for subsequent pages, increment by the limit value (e.g., 0, 10, 20...).",
        },
        tags: {
          type: "string",
          description: "Pipe-separated list of tag IDs to filter by (optional, e.g., '5|12|37'). Use get_tags to see available tag IDs.",
        },
        pillars: {
          type: "string",
          description: "Pipe-separated list of pillar/organization tag IDs to filter by (optional, e.g., '3|7').",
        },
        users: {
          type: "string",
          description: "Pipe-separated list of author user IDs to filter by (optional, e.g., '101|205'). Filters by the article's author.",
        },
        owners: {
          type: "string",
          description: "Pipe-separated list of owner IDs to filter by (optional). Filters by the content owner.",
        },
        binderids: {
          type: "string",
          description: "Pipe-separated list of binder IDs to filter by (optional, e.g., '5|12|37'). When provided, only content belonging to these binders is returned (hard filter).",
        },
      },
      required: ["query"],
    },
  },
  {
    name: "save_content",
    description: "Create or update a KB article. Omit contentid to create new content; provide contentid to update existing content. IMPORTANT: The content body must be HTML — Markdown is NOT supported. The server automatically base64-encodes the HTML before transmission. For new content, title, content, and typeid are required. Use get_types for valid type IDs, get_tags for tag IDs. Use find_content_by_title first to check if an article with the same title already exists. After creating content, use insert_binder_content to add it to a binder.",
    inputSchema: {
      type: "object",
      properties: {
        contentid: {
          type: "number",
          description: "Content ID for update (omit to create new content). Use find_content_by_title or search_content to find existing content IDs.",
        },
        title: {
          type: "string",
          description: "Title of the content (required for new content, optional for update)",
        },
        content: {
          type: "string",
          description: "Content body in HTML format (required for new content). Markdown is NOT supported — use HTML tags like <p>, <h2>, <ul>, <code>, etc. The content will be automatically base64-encoded before transmission.",
        },
        typeid: {
          type: "number",
          description: "Content type ID (required for new content). Use get_types to see available types.",
        },
        contentTagging: {
          type: "string",
          description: "Comma-separated list of tag IDs (recommended). Use get_tags to see available tags.",
        },
        archived: {
          type: "number",
          description: "Archive status: 0 for active, 1 for archived (default: 0). Archiving hides the content from search results.",
        },
        organizationtags: {
          type: "string",
          description: "Comma-separated list of organization tag IDs (recommended). Use get_tags with tagtypeid=3 to see organization tags.",
        },
      },
    },
  },
  {
    name: "get_recent_content",
    description: "Get recently created or updated KB articles. Returns the latest content that has been created or modified, useful for staying current with new knowledge. Results include content IDs that can be passed to get_content for full details.",
    inputSchema: {
      type: "object",
      properties: {
        typeid: {
          type: "number",
          description: "Filter by content type ID (optional). Use get_types to see available types.",
        },
      },
    },
  },
  {
    name: "get_favorite_content",
    description: "Get the current user's favorite KB articles. Returns a list of content previously bookmarked via add_favorite. Results include content IDs that can be passed to get_content for full details.",
    inputSchema: {
      type: "object",
      properties: {},
    },
  },
  {
    name: "find_content_by_title",
    description: "Find a KB article by exact title match. Returns the contentid if found, 0 if no match. Only searches non-archived content and returns the most recently created match. Use this before save_content to check if an article with the same title already exists and avoid duplicates. For fuzzy/keyword search, use search_content instead.",
    inputSchema: {
      type: "object",
      properties: {
        title: {
          type: "string",
          description: "Exact title to search for (case-sensitive, must match exactly)",
        },
      },
      required: ["title"],
    },
  },
  {
    name: "get_tags",
    description: "Get available tags from the KB system. Tags are used to categorize content (via save_content's contentTagging/organizationtags params) and to manage binder permissions. Tag types: 0/null = General (Technical, Reference, JS, etc.), 1 = System (New, Recently Updated), 2 = Admin (Showcase), 3 = Organization (PM, CSD, NSD, IT, etc.), 4 = UserPrivate (Favorite), 5 = UserPublic (Contributor, Author). Filter by tagtypeid to get a specific category.",
    inputSchema: {
      type: "object",
      properties: {
        tagtypeid: {
          type: "number",
          description: "Filter by tag type ID (optional). Common values: 3 for organization tags (used in save_content organizationtags), omit for general content tags.",
        },
      },
    },
  },
  {
    name: "get_types",
    description: "Get all available content types from the KB system. Returns type IDs and names. A typeid is required when creating new content via save_content. Call this to discover valid type IDs before creating content.",
    inputSchema: {
      type: "object",
      properties: {},
    },
  },
  {
    name: "add_favorite",
    description: "Bookmark a KB article by adding it to the current user's favorites list. Favorited content can be retrieved later via get_favorite_content. This records a 'favorite' action in the article's history.",
    inputSchema: {
      type: "object",
      properties: {
        contentid: {
          type: "number",
          description: "Content ID to add to favorites. Obtain from search_content, get_content, or get_recent_content.",
        },
      },
      required: ["contentid"],
    },
  },
  {
    name: "remove_favorite",
    description: "Remove a KB article from the current user's favorites list (undo add_favorite). The article itself is not affected — it is only unbookmarked for the current user.",
    inputSchema: {
      type: "object",
      properties: {
        contentid: {
          type: "number",
          description: "Content ID to remove from favorites. Use get_favorite_content to see currently favorited items.",
        },
      },
      required: ["contentid"],
    },
  },
  {
    name: "get_history",
    description: "Get the full audit trail for a KB article. Returns a chronological list of all actions performed on the content, including who performed each action and when. Action types: create, update, view, archive, favorite, showcase, upvote, downvote, clearvote, followup, subscription. Useful for understanding an article's lifecycle and recent activity.",
    inputSchema: {
      type: "object",
      properties: {
        contentid: {
          type: "number",
          description: "Content ID to get history for. Obtain from search_content, get_content, or get_recent_content.",
        },
        limit: {
          type: "number",
          description: "Maximum number of history records to return (optional). Omit for all records.",
        },
      },
      required: ["contentid"],
    },
  },
  {
    name: "get_user_binders",
    description: "List all binders accessible to the current user. Returns binders owned by, shared with, and org-level binders. Optionally filter by name. This is the recommended starting point for discovering binders. Each result includes a binder ID that can be used with get_binder_contents to see the full content tree.",
    inputSchema: {
      type: "object",
      properties: {
        name: {
          type: "string",
          description: "Optional name filter (case-insensitive substring match)",
        },
      },
    },
  },
  {
    name: "get_binder",
    description: "Get detailed information about a specific binder by its ID, including name, description, visibility, owner, and admin/editor user lists. Use get_binder_contents to see the binder's hierarchical content tree.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to retrieve",
        },
      },
      required: ["binderid"],
    },
  },
  {
    name: "get_binder_contents",
    description: "Get the full content tree of a binder (calls getPopulatedBinder). Returns a struct with: binderdetails (metadata), bindercontent (hierarchical list of sections — each with ID, name, parentID, contentID, extLink, shortcutid, isfolder, level, and sortorder), and binderfolderpath (breadcrumb). Use sectionID to scope to a specific folder. The section IDs returned here are used by insert_binder_content, update_binder_content, archive_binder_content, and update_binder_content_rank.",
    inputSchema: {
      type: "object",
      properties: {
        binderID: {
          type: "number",
          description: "The binder ID to retrieve contents for",
        },
        sectionID: {
          type: "number",
          description: "Optional section ID to scope to a specific folder within the binder",
        },
      },
      required: ["binderID"],
    },
  },
  {
    name: "search_binder_content",
    description: "Search for content within a specific binder using full-text Elasticsearch. Filters results to only include content that belongs to the specified binder. Use get_binder_contents for browsing the tree structure, and this tool for keyword search within a binder.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to search within",
        },
        query: {
          type: "string",
          description: "Search query string",
        },
        limit: {
          type: "number",
          description: "Maximum number of results to return (default: 10)",
        },
      },
      required: ["binderid", "query"],
    },
  },
  {
    name: "list_binders",
    description: "List all binders system-wide (not scoped to the current user like get_user_binders). Returns all non-archived binders. Optionally filter by organization ID (returns Owned/Subscribed grouping), owner ID, name (SQL LIKE), and/or subscription status.",
    inputSchema: {
      type: "object",
      properties: {
        orgid: {
          type: "string",
          description: "Optional organization ID to filter binders by (returns Owned/Subscribed grouping when provided)",
        },
        ownerid: {
          type: "number",
          description: "Optional owner ID to filter binders by",
        },
        name: {
          type: "string",
          description: "Optional name filter (SQL LIKE substring match)",
        },
        subscribed: {
          type: "string",
          description: "Optional subscription filter: 'Owned' or 'Subscribed' (only applies when orgid is provided)",
        },
      },
    },
  },
  {
    name: "insert_binder",
    description: "Create a new binder. The current user is automatically added as an admin. Returns the newly created binder with its binderid, which can then be used with insert_binder_content to add articles, folders, and links. Requires the user to be logged in. For org-owned binders, the user's band level must meet the org's 'create' permission threshold.",
    inputSchema: {
      type: "object",
      properties: {
        name: {
          type: "string",
          description: "Name of the binder (max 100 characters)",
        },
        description: {
          type: "string",
          description: "Description of the binder (max 500 characters)",
        },
        public: {
          type: "number",
          description: "Visibility: 1 for public, 0 for private",
        },
        binderEditTag: {
          type: "string",
          description: "Comma-separated list of user IDs to grant editor permissions",
        },
        binderAdminTag: {
          type: "string",
          description: "Comma-separated list of user IDs to grant admin permissions",
        },
        isOrgOwned: {
          type: "boolean",
          description: "Whether the binder is owned by the user's organization (default: false)",
        },
      },
      required: ["name", "description", "public"],
    },
  },
  {
    name: "update_binder",
    description: "Update an existing binder's metadata, name, description, visibility, and admin/editor assignments. Requires admin permission on the binder (check with get_binder_permissions). At least one admin user must always be assigned. Replaces the full admin/editor lists — provide all desired user IDs, not just changes.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to update",
        },
        name: {
          type: "string",
          description: "Updated name of the binder",
        },
        description: {
          type: "string",
          description: "Updated description of the binder",
        },
        public: {
          type: "number",
          description: "Visibility: 1 for public, 0 for private",
        },
        binderEditTag: {
          type: "string",
          description: "Comma-separated list of user IDs to grant editor permissions",
        },
        binderAdminTag: {
          type: "string",
          description: "Comma-separated list of user IDs to grant admin permissions (required, at least one admin)",
        },
      },
      required: ["binderid", "name", "binderAdminTag"],
    },
  },
  {
    name: "archive_binder",
    description: "Archive (or unarchive) a binder — toggles the archive status. Only binder admins can archive binders. Archived binders are hidden from listing results. This does not delete the binder or its content.",
    inputSchema: {
      type: "object",
      properties: {
        binderID: {
          type: "number",
          description: "The binder ID to archive",
        },
      },
      required: ["binderID"],
    },
  },
  {
    name: "leave_binder",
    description: "Leave a binder. Removes the current user's admin and editor permissions from the binder.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to leave",
        },
      },
      required: ["binderid"],
    },
  },
  {
    name: "subscribe_to_binder",
    description: "Subscribe or unsubscribe the current user's organization to/from a binder. Toggles subscription — if already subscribed, it unsubscribes, and vice versa. Subscribing makes the binder visible to org members in list_binders (with orgid). Requires the user's band level to meet the org's 'subscribe' permission threshold.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to subscribe to or unsubscribe from",
        },
      },
      required: ["binderid"],
    },
  },
  {
    name: "insert_binder_content",
    description: "Add a new section to a binder's content tree. A section can be a KB article link (set contentid), a folder (set isfolder=1), an external link (set extlink), or a shortcut to another section (set shortcutid). Only one link type per section. Use sectionid to place it under a specific folder, or omit/0 for root level. Requires editor permission on the binder. A KB article (contentid) can only appear once per binder. Returns the newly created section with its sectionid.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to add content to",
        },
        sectionid: {
          type: "number",
          description: "Parent section ID (folder) to add under. 0 or omit for root level.",
        },
        name: {
          type: "string",
          description: "Display name for the binder item (max 50 characters)",
        },
        contentid: {
          type: "number",
          description: "KB content ID to link (for article links)",
        },
        isfolder: {
          type: "number",
          description: "Set to 1 to create a folder, 0 for content item (default: 0)",
        },
        extlink: {
          type: "string",
          description: "External URL to link (for external links)",
        },
        shortcutid: {
          type: "number",
          description: "Section ID to create a shortcut to",
        },
      },
      required: ["binderid", "name"],
    },
  },
  {
    name: "update_binder_content",
    description: "Update an existing binder section by its sectionid. Can rename it, change its linked content/link/shortcut, adjust sort order, or move it to a different parent folder (parentid). Requires editor permission on the binder. Get section IDs from get_binder_contents.",
    inputSchema: {
      type: "object",
      properties: {
        sectionid: {
          type: "number",
          description: "The section ID to update",
        },
        name: {
          type: "string",
          description: "Updated display name",
        },
        contentid: {
          type: "number",
          description: "Updated KB content ID link",
        },
        sortorder: {
          type: "number",
          description: "Updated sort order",
        },
        parentid: {
          type: "number",
          description: "Updated parent section ID (to move into a different folder)",
        },
        extlink: {
          type: "string",
          description: "Updated external URL link",
        },
        shortcutid: {
          type: "number",
          description: "Updated shortcut target section ID",
        },
      },
      required: ["sectionid", "name"],
    },
  },
  {
    name: "archive_binder_content",
    description: "Archive a binder section by its sectionid. If the section is a folder, all child sections and shortcuts pointing to it are also archived. The binder must retain at least one item — the last remaining section cannot be archived. Requires editor permission. This does not delete the underlying KB article, only removes it from the binder.",
    inputSchema: {
      type: "object",
      properties: {
        sectionid: {
          type: "number",
          description: "The section ID to archive",
        },
      },
      required: ["sectionid"],
    },
  },
  {
    name: "insert_binder_tab",
    description: "Add a new empty root-level folder (tab) named 'New folder' to a binder. The binder can have at most 3 empty folders at once — populate existing empty folders before adding more. For adding folders with custom names or nested folders, use insert_binder_content with isfolder=1 instead.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to add a tab to",
        },
      },
      required: ["binderid"],
    },
  },
  {
    name: "move_binder_content_to_root",
    description: "Move a binder section to the root level of its binder, removing it from its current parent folder. Requires editor permission. For moving a section into a different folder, use update_binder_content with parentid, or update_binder_content_rank with actionType='subordinate'.",
    inputSchema: {
      type: "object",
      properties: {
        sectionId: {
          type: "number",
          description: "The section ID to move to root",
        },
      },
      required: ["sectionId"],
    },
  },
  {
    name: "update_binder_content_rank",
    description: "Reorder binder sections by positioning one section relative to another. Use actionType='subordinate' to make the source a child of the destination (move into folder), or actionType='equal' to make them siblings. placeSourceAfterDestination controls whether it goes before or after. Requires editor permission. Get section IDs from get_binder_contents.",
    inputSchema: {
      type: "object",
      properties: {
        sourceId: {
          type: "number",
          description: "The section ID being moved",
        },
        destinationId: {
          type: "number",
          description: "The section ID to position relative to",
        },
        actionType: {
          type: "string",
          description: "Relationship type: 'subordinate' (make child of destination) or 'equal' (make sibling of destination)",
          enum: ["subordinate", "equal"],
        },
        placeSourceAfterDestination: {
          type: "boolean",
          description: "Whether to place the source after the destination (true) or before it (false)",
        },
      },
      required: ["sourceId", "destinationId", "actionType", "placeSourceAfterDestination"],
    },
  },
  {
    name: "get_binder_permissions",
    description: "Get the current user's permission tags for a specific binder. Returns a comma-separated list of permission names (e.g., 'Binder Admin', 'Binder Edit'). Use this before attempting write operations to verify the user has the required access level. Admin is needed for update_binder and archive_binder; Editor is needed for insert_binder_content, update_binder_content, archive_binder_content, and reordering tools.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID to check permissions for",
        },
      },
      required: ["binderid"],
    },
  },
  {
    name: "get_binder_section",
    description: "Get details of a single binder section by its section ID. Returns id, binderid, name, parentid, contentid, extlink, isFolder, shortcutid, and archive status. Useful for inspecting a specific item before updating or archiving it.",
    inputSchema: {
      type: "object",
      properties: {
        sectionID: {
          type: "number",
          description: "The section ID to retrieve",
        },
        excludeArchived: {
          type: "number",
          description: "Whether to exclude archived sections (1 = exclude, 0 = include, default: 1)",
        },
      },
      required: ["sectionID"],
    },
  },
  {
    name: "get_binder_folder_path",
    description: "Get the folder breadcrumb path for a section within a binder. Returns the hierarchy of parent folders from root to the section's location. Useful for displaying navigation context or understanding where a section sits in the binder tree.",
    inputSchema: {
      type: "object",
      properties: {
        binderid: {
          type: "number",
          description: "The binder ID",
        },
        sectionid: {
          type: "number",
          description: "The section ID to get the folder path for",
        },
      },
      required: ["binderid", "sectionid"],
    },
  },
  {
    name: "get_binder_ids_for_content",
    description: "Find all binders that contain a specific KB content article (by contentid). Returns a deduplicated comma-separated list of binder IDs. Useful for understanding where an article is curated and for avoiding duplicate insertion (insert_binder_content will reject a contentid that already exists in the target binder).",
    inputSchema: {
      type: "object",
      properties: {
        contentid: {
          type: "number",
          description: "The KB content ID to search for across binders",
        },
      },
      required: ["contentid"],
    },
  },
  {
    name: "get_binders_by_org",
    description: "Get all binders for an organization (by orgid), including both owned and subscribed binders, along with the org's binder permission settings (create, edit content, edit meta, subscribe thresholds). Returns a struct with 'binders' (the list) and 'permissions' (org-level permission bands).",
    inputSchema: {
      type: "object",
      properties: {
        orgid: {
          type: "string",
          description: "The organization ID to get binders for",
        },
      },
      required: ["orgid"],
    },
  },
  {
    name: "call_method",
    description: "Call any public kbx.cfc method dynamically by name. This is a fallback for methods not exposed as dedicated tools above. Examples of methods available through this tool: getRecentActivity, getCommentsListing, commentPost, upVote, downVote, clearVote, countVotings, followup, subscription, getFollowup, getOrganizations, getKBUsers, getKBUserInfo, addExpert, removeExpert, flagContentForReview, reassignArticleOwner, getTaggingList, checkIsKBAdmin, and more. Pass method name and a params object with the required arguments.",
    inputSchema: {
      type: "object",
      properties: {
        method: {
          type: "string",
          description: "The KB method name to call (must be a public method in kbx.cfc). Examples: 'getRecentActivity', 'commentPost', 'upVote', 'getOrganizations', 'getKBUsers'.",
        },
        params: {
          type: "object",
          description: "Parameters to pass to the method as key-value pairs. Parameter names and types depend on the specific method being called.",
        },
      },
      required: ["method"],
    },
  },
  {
    name: "get_content_url",
    description: "Get the browser URL for a KB article. Returns the URL that can be used to open the KB content/article in a web browser.",
    inputSchema: {
      type: "object",
      properties: {
        contentid: {
          type: "number",
          description: "The content ID of the KB article",
        },
      },
      required: ["contentid"],
    },
  },
];

/**
 * Map tool names to KB method names
 */
export const TOOL_METHOD_MAP: Record<string, string> = {
  get_content: "getContent",
  search_content: "searchAsAgent",
  save_content: "saveContent",
  get_recent_content: "getRecentContent",
  get_favorite_content: "getFavoriteContent",
  find_content_by_title: "findContentByTitle",
  // get_tags handled via custom handler (routes to getTag or getTagsOfTagType)
  get_types: "getType",
  add_favorite: "addFavorite",
  remove_favorite: "removeFavorite",
  get_history: "getHistory",
  get_binder: "getBinder",
  get_binder_contents: "getPopulatedBinder",
  insert_binder: "insertBinder",
  update_binder: "updateBinder",
  archive_binder: "archiveBinder",
  leave_binder: "leaveBinder",
  subscribe_to_binder: "subscribeToBinder",
  insert_binder_content: "insertBinderContent",
  update_binder_content: "updateBinderContent",
  archive_binder_content: "archiveBinderContent",
  insert_binder_tab: "insertBinderTab",
  move_binder_content_to_root: "moveBinderContentToRoot",
  update_binder_content_rank: "updateBinderContentRank",
  get_binder_permissions: "getBinderPermissions",
  get_binder_section: "getBinderSection",
  get_binder_folder_path: "getBinderFolderPath",
  get_binder_ids_for_content: "getBinderIdsForContentId",
  get_binders_by_org: "getBindersByOrgId",
};
