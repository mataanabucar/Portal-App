#!/bin/bash
# One-liner install script for KB MCP Server
# Usage: curl -so- https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.sh | bash
# Or:    wget -qO- https://code.gensuite.com/devops/kb-mcp-server/-/raw/main/install.sh | bash

set -e

echo "KB MCP Server - Quick Install"
echo "============================="
echo ""

# Check for required tools
if ! command -v npm &> /dev/null; then
    echo "✗ npm is required but not installed. Please install Node.js from https://nodejs.org/"
    exit 1
fi

# Determine npmrc file location
NPMRC_PATH="$HOME/.npmrc"

echo "This script will help you:"
echo "1. Create a GitLab Personal Access Token"
echo "2. Configure your .npmrc file at: $NPMRC_PATH"
echo ""

# Open GitLab in browser
echo "Step 1: Create GitLab Personal Access Token"
echo "-------------------------------------------"
echo "Opening GitLab Access Tokens page in your browser..."
echo ""

TOKEN_URL="https://code.gensuite.com/-/user_settings/personal_access_tokens"

# Try to open browser (works on most systems)
if command -v xdg-open &> /dev/null; then
    xdg-open "$TOKEN_URL" 2>/dev/null &
elif command -v open &> /dev/null; then
    open "$TOKEN_URL" 2>/dev/null &
elif command -v start &> /dev/null; then
    start "$TOKEN_URL" 2>/dev/null &
else
    echo "Please open this URL in your browser: $TOKEN_URL"
fi

echo "In the browser that just opened:"
echo "1. Enter a token name (e.g., 'KB MCP Server')"
echo "2. Set an expiration date (optional)"
echo "3. Select the following scopes:"
echo "   ✓ read_api"
echo "   ✓ read_registry"
echo "4. Click 'Create personal access token'"
echo "5. COPY THE TOKEN IMMEDIATELY (you won't see it again!)"
echo ""

# Get token from user with validation loop
TOKEN=""
while true; do
    # Always read from /dev/tty to ensure we can read from terminal even when piped
    # This allows typing and copy/paste to work properly
    if [ -c /dev/tty ]; then
        read -p "Paste your GitLab Personal Access Token here: " TOKEN < /dev/tty
    else
        read -p "Paste your GitLab Personal Access Token here: " TOKEN
    fi
    echo ""

    if [ -z "$TOKEN" ]; then
        echo "✗ Token is required. Please try again."
        continue
    fi

    # Remove carriage returns (handle CRLF line endings)
    TOKEN=$(echo "$TOKEN" | tr -d '\r')

    # Validate token format (GitLab personal access tokens: glpat- followed by 20 alphanumeric characters, underscores, or hyphens)
    if [[ "$TOKEN" =~ ^glpat-[0-9a-zA-Z_\-]{20}$ ]]; then
        break
    else
        echo "✗ Invalid token format. GitLab personal access tokens should be in the format: glpat- followed by 20 alphanumeric characters, underscores, or hyphens"
        echo "  Please try again."
    fi
done

# Configure .npmrc
echo ""
echo "Step 2: Configuring .npmrc"
echo "--------------------------"

REGISTRY_URL="https://code.gensuite.com/api/v4/packages/npm/"
AUTH_TOKEN_LINE="//code.gensuite.com/api/v4/packages/npm/:_authToken=$TOKEN"

# Read existing .npmrc if it exists
if [ -f "$NPMRC_PATH" ]; then
    echo "Found existing .npmrc file"
    EXISTING_CONTENT=$(cat "$NPMRC_PATH")
else
    echo "Creating new .npmrc file"
    EXISTING_CONTENT=""
fi

# Check if @devops:registry already exists
if ! echo "$EXISTING_CONTENT" | grep -q "@devops:registry="; then
    echo "@devops:registry=$REGISTRY_URL" >> "$NPMRC_PATH"
else
    echo "Updating existing @devops:registry entry"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s|@devops:registry=.*|@devops:registry=$REGISTRY_URL|" "$NPMRC_PATH"
    else
        # Linux
        sed -i "s|@devops:registry=.*|@devops:registry=$REGISTRY_URL|" "$NPMRC_PATH"
    fi
fi

# Check if auth token already exists
if ! echo "$EXISTING_CONTENT" | grep -q "//code\.gensuite\.com/api/v4/packages/npm/:_authToken="; then
    echo "$AUTH_TOKEN_LINE" >> "$NPMRC_PATH"
else
    echo "Updating existing auth token"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s|//code\.gensuite\.com/api/v4/packages/npm/:_authToken=.*|$AUTH_TOKEN_LINE|" "$NPMRC_PATH"
    else
        # Linux
        sed -i "s|//code\.gensuite\.com/api/v4/packages/npm/:_authToken=.*|$AUTH_TOKEN_LINE|" "$NPMRC_PATH"
    fi
fi

echo "✓ .npmrc file configured successfully!"
echo ""
echo "Configuration added to: $NPMRC_PATH"
echo ""
echo "Next steps:"
echo "1. Open Cursor Settings (File > Preferences > Cursor Settings)"
echo "2. Navigate to Tools & MCP"
echo "3. Click + New MCP Server"
echo "4. Add the following configuration:"
echo ""
cat << 'EOF'
{
  "mcpServers": {
    "kb": {
      "command": "npx",
      "args": ["-y", "@devops/kb-mcp-server"]
    }
  }
}
EOF
echo ""
echo "Then restart Cursor and start using KB tools in conversations with \"use kb;\""
echo ""
