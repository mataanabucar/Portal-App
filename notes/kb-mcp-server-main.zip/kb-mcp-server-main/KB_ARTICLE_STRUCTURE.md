# KB MCP Server Content ID for the KB is 2989


# KB MCP Server Article Organization Guidelines

This document defines the required structure and organization for the Knowledge Base MCP Server article in the KB system.

## Article Structure

The article must be organized into **two distinct sections**:

### Section 1: Integration with Cursor (Primary Focus)

This section should come **immediately after the Introduction** and cover everything end users need to integrate the MCP server into Cursor. This is the primary use case.

**Required subsections:**
1. **Quick Installation**
   - One-liner install scripts (Linux/Mac/Windows)
   - Explanation of what the scripts do (.npmrc configuration)

2. **Cursor Configuration**
   - MCP settings JSON configuration
   - How to access Cursor MCP settings
   - Complete configuration example with `mcpServers` structure

3. **Authentication Token Setup**
   - `KB_AUTH_TOKEN` environment variable details
   - JWT token generation instructions
   - Token expiration and security information
   - Configuration notes (npx flag, endpoint defaults, etc.)

4. **Usage Patterns**
   - How to use after configuration
   - Example natural language queries
   - Restart instructions

### Section 2: Architecture and Technical Details

This section should come **after the Integration section** and include all technical, architectural, and development information.

**Required subsections:**
1. **Architecture Overview**
   - System Components (diagram)
   - Technology Stack

2. **Core Functionality**
   - Content Management Operations
   - User Engagement Features
   - Advanced Features

3. **Data Encoding and Transmission**
   - Base64 Encoding
   - HTTP Method Selection

4. **Response Format**
   - JSON response structure
   - Error handling

5. **Development and Deployment**
   - Local Development Setup (for contributors)
   - Development Workflow
   - HTTP Server Adapter
   - Environment Configuration

6. **Technical Implementation Details**
   - Method Mapping table
   - Parameter Transformation
   - Error Handling

7. **Use Cases**
8. **Future Enhancements**
9. **Conclusion**
10. **References**

## Key Principles

1. **End users first**: The Cursor integration section must be the first thing users see after the introduction
2. **Clear separation**: Keep integration instructions completely separate from architecture/development details
3. **No local dev-only config in user docs**: Never mention Cloudflare Access credentials (`KB_CF_ACCESS_CLIENT_ID`/`KB_CF_ACCESS_CLIENT_SECRET`) or session cookies (`KB_COOKIES`) in user-facing documentation - these are only for local development
4. **Only npx installation**: Only document the npx-based installation method via install scripts - no manual npm install instructions
5. **Version information**: Always include current version in Technology Stack section

## Content ID

The KB article content ID is: **2989**

## Maintenance

When updating the KB article:
1. Always follow this structure
2. Keep Section 1 focused on end-user integration
3. Keep Section 2 focused on technical/development details
4. Verify that local dev-only configuration options are not mentioned in user-facing sections
