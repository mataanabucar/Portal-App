# KB MCP Server - AWS ECS Deployment Guide

This guide explains how to deploy the KB MCP Server to AWS ECS for handling concurrent requests at scale.

## Architecture Overview

The deployment includes:
- **ECS Fargate** tasks running the HTTP server
- **Application Load Balancer (ALB)** for traffic distribution
- **Auto Scaling** based on CPU and memory utilization
- **CloudWatch Logs** for monitoring
- **Secrets Manager** for secure credential storage

## Prerequisites

1. AWS CLI configured with appropriate permissions
2. Docker installed locally
3. AWS ECR repository created
4. VPC with at least 2 public subnets
5. Secrets Manager secrets created for:
   - `KB_ENDPOINT`
   - `KB_AUTH_TOKEN`

## Step 1: Build and Push Docker Image

```bash
# Navigate to the mcp-server directory
cd mcp-server

# Build the Docker image
docker build -t kb-mcp-server:latest .

# Tag for ECR (replace with your account ID and region)
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com

docker tag kb-mcp-server:latest YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/kb-mcp-server:latest

# Push to ECR
docker push YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/kb-mcp-server:latest
```

## Step 2: Create Secrets in AWS Secrets Manager

```bash
# Create KB_ENDPOINT secret
aws secretsmanager create-secret \
  --name kb-mcp-server/KB_ENDPOINT \
  --secret-string "https://tools.benchmarkdigital.com/kb/callKBX.cfm" \
  --region us-east-1

# Create KB_AUTH_TOKEN secret
aws secretsmanager create-secret \
  --name kb-mcp-server/KB_AUTH_TOKEN \
  --secret-string "your-jwt-token-here" \
  --region us-east-1
```

## Step 3: Deploy CloudFormation Stack

```bash
# Deploy the stack
aws cloudformation create-stack \
  --stack-name kb-mcp-server \
  --template-body file://cloudformation-ecs.yaml \
  --parameters \
    ParameterKey=ImageUri,ParameterValue=YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/kb-mcp-server:latest \
    ParameterKey=VpcId,ParameterValue=vpc-xxxxxxxxx \
    ParameterKey=SubnetIds,ParameterValue="subnet-xxxxxxxxx,subnet-yyyyyyyyy" \
    ParameterKey=KbEndpointSecretArn,ParameterValue=arn:aws:secretsmanager:us-east-1:YOUR_ACCOUNT_ID:secret:kb-mcp-server/KB_ENDPOINT-xxxxx \
    ParameterKey=KbAuthTokenSecretArn,ParameterValue=arn:aws:secretsmanager:us-east-1:YOUR_ACCOUNT_ID:secret:kb-mcp-server/KB_AUTH_TOKEN-xxxxx \
  --capabilities CAPABILITY_NAMED_IAM \
  --region us-east-1

# Wait for stack creation
aws cloudformation wait stack-create-complete --stack-name kb-mcp-server --region us-east-1
```

## Step 4: Configure SSL Certificate (Optional but Recommended)

1. Request or import an SSL certificate in AWS Certificate Manager (ACM)
2. Update the CloudFormation template's `HTTPSListener` resource to include the certificate ARN
3. Update the stack:

```bash
aws cloudformation update-stack \
  --stack-name kb-mcp-server \
  --template-body file://cloudformation-ecs.yaml \
  --parameters ... # (same parameters as before)
```

## Step 5: Verify Deployment

```bash
# Get the ALB DNS name
aws cloudformation describe-stacks \
  --stack-name kb-mcp-server \
  --query 'Stacks[0].Outputs[?OutputKey==`LoadBalancerDNS`].OutputValue' \
  --output text

# Test health endpoint
curl https://YOUR_ALB_DNS_NAME/health

# Test tools endpoint
curl https://YOUR_ALB_DNS_NAME/tools

# Test tool call
curl -X POST https://YOUR_ALB_DNS_NAME/call \
  -H "Content-Type: application/json" \
  -d '{
    "name": "kb_get_types",
    "arguments": {}
  }'
```

## Configuration

### Environment Variables

The container supports the following environment variables:

- `PORT` (default: 3000) - HTTP server port
- `NODE_ENV` (default: production) - Node.js environment
- `KB_ENDPOINT` - KB API endpoint (from Secrets Manager)
- `KB_AUTH_TOKEN` - JWT authentication token (from Secrets Manager)

### Scaling Configuration

The service is configured with auto-scaling:
- **Min Capacity**: 2 tasks
- **Max Capacity**: 10 tasks
- **CPU Target**: 70% utilization
- **Memory Target**: 80% utilization

Adjust these values in the CloudFormation template or via the AWS Console.

### Resource Allocation

Default task resources:
- **CPU**: 512 units (0.5 vCPU)
- **Memory**: 1024 MB (1 GB)

For higher concurrency, increase these values:
- 1024 CPU / 2048 MB for ~2x capacity
- 2048 CPU / 4096 MB for ~4x capacity

## Monitoring

### CloudWatch Logs

View logs:
```bash
aws logs tail /ecs/kb-mcp-server --follow
```

### CloudWatch Metrics

Monitor:
- `CPUUtilization` - Task CPU usage
- `MemoryUtilization` - Task memory usage
- `RequestCount` - ALB request count
- `TargetResponseTime` - Average response time

### Health Checks

The service includes:
- Container health check on `/health` endpoint
- ALB health check on `/health` endpoint
- Automatic task replacement on health check failures

## Updating the Service

### Update Docker Image

```bash
# Build and push new image
docker build -t kb-mcp-server:latest .
docker tag kb-mcp-server:latest YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/kb-mcp-server:latest
docker push YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/kb-mcp-server:latest

# Force new deployment
aws ecs update-service \
  --cluster kb-mcp-server-cluster \
  --service kb-mcp-server-service \
  --force-new-deployment \
  --region us-east-1
```

### Update Configuration

Modify the CloudFormation template and update the stack:
```bash
aws cloudformation update-stack \
  --stack-name kb-mcp-server \
  --template-body file://cloudformation-ecs.yaml \
  --parameters ... # (updated parameters)
```

## API Endpoints

Once deployed, the service exposes:

- `GET /` - API information
- `GET /health` - Health check
- `GET /tools` - List available KB tools
- `POST /call` - Execute a KB tool

### Example API Usage

```bash
# List tools
curl https://YOUR_ALB_DNS_NAME/tools

# Search KB content
curl -X POST https://YOUR_ALB_DNS_NAME/call \
  -H "Content-Type: application/json" \
  -d '{
    "name": "kb_search_content",
    "arguments": {
      "query": "MCP",
      "limit": 10
    }
  }'

# Get content by ID
curl -X POST https://YOUR_ALB_DNS_NAME/call \
  -H "Content-Type: application/json" \
  -d '{
    "name": "kb_get_content",
    "arguments": {
      "contentid": 2989
    }
  }'
```

## Troubleshooting

### Tasks Not Starting

1. Check CloudWatch Logs for errors
2. Verify Secrets Manager permissions
3. Check ECR image pull permissions
4. Verify security group rules

### High Latency

1. Increase task CPU/memory allocation
2. Add more tasks (increase desired count)
3. Check ALB target group health
4. Monitor CloudWatch metrics

### Health Check Failures

1. Verify `/health` endpoint is accessible
2. Check container logs
3. Verify port 3000 is exposed
4. Check security group rules

## Cost Optimization

- Use **Fargate Spot** for non-production workloads (50-70% savings)
- Adjust auto-scaling min/max based on actual usage
- Use CloudWatch Logs retention policies
- Consider Reserved Capacity for predictable workloads

## Security Best Practices

1. **Use HTTPS** - Configure SSL certificate in ALB
2. **Secrets Management** - Never hardcode credentials
3. **Network Security** - Use security groups to restrict access
4. **IAM Roles** - Follow principle of least privilege
5. **VPC** - Deploy in private subnets with NAT Gateway for production

## Cleanup

To remove all resources:

```bash
# Delete CloudFormation stack
aws cloudformation delete-stack --stack-name kb-mcp-server --region us-east-1

# Wait for deletion
aws cloudformation wait stack-delete-complete --stack-name kb-mcp-server --region us-east-1

# Delete ECR images (optional)
aws ecr batch-delete-image \
  --repository-name kb-mcp-server \
  --image-ids imageTag=latest \
  --region us-east-1
```

## Support

For issues or questions, refer to:
- CloudWatch Logs: `/ecs/kb-mcp-server`
- ECS Service Events in AWS Console
- Application logs via CloudWatch Logs Insights
